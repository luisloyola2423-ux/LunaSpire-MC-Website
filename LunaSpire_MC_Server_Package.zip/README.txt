LUNASPIRE MC — BEDROCK SERVER PACKAGE

Server settings
- Survival
- Max players: 200
- PvP enabled
- Normal difficulty
- Default world generation
- Spawn point: 0, 65, 0

SPAWN / TOWN AREA
A one-time behavior-pack setup creates a 129 x 129 flat grass town area centered on world spawn.
The area is flattened and cleared above the surface so you can build a town.
Natural terrain remains outside the town area.

IMPORTANT
This ZIP is the server configuration/package. It does not include the proprietary Minecraft Bedrock Dedicated Server executable.
To run a real multiplayer server, extract this package into a compatible Bedrock Dedicated Server installation/host.

BEHAVIOR PACK
The pack is included in behavior_packs/LunaSpire_Spawn.
The worlds/LunaSpire/world_behavior_packs.json file enables it for the LunaSpire world.

If your host generates a brand-new world folder and does not preserve world files, copy
worlds/LunaSpire/world_behavior_packs.json into the generated LunaSpire world folder.

The setup uses a scoreboard flag so the spawn area is only created once and player builds are not repeatedly erased.
