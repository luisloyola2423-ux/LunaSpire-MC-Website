# LunaSpire MC one-time spawn setup
scoreboard objectives add lunaspire_setup dummy
scoreboard players add #done lunaspire_setup 0
execute if score #done lunaspire_setup matches 0 run function setup_once
