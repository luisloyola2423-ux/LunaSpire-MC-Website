LUNASPIRE MC - BEDROCK SERVER STARTER PACKAGE

Server settings:
- Name: LunaSpire MC
- Survival
- Normal difficulty
- PvP enabled
- Maximum players: 200
- Public (allow-list disabled)
- 24/7 hosting-ready
- No custom gameplay addons
- Default/natural world generation

SPAWN/TOWN AREA:
The included LunaSpire_Spawn behavior pack contains setup.mcfunction.
It creates a 129 x 129 flat grass building zone centered at world spawn.
Outside that zone, the world remains normal/default terrain, so mountains,
rivers, forests and other natural features can generate normally.

IMPORTANT:
This package is a starter configuration, not a hosted server. You still
need to install the official Bedrock Dedicated Server on a machine/host that
stays online 24/7, then place server.properties in the server folder and
install/enable the behavior pack in the generated world.

For a production 200-player server, use a host with sufficient CPU/RAM and
network bandwidth. The actual capacity depends on simulation distance,
view distance, world activity, and hosting hardware.

Do not run setup.mcfunction repeatedly after players have built in the area,
because it clears the area above the pad.
