# LunaSpire MC spawn/town preparation
# Flat grass surface: x/z -64..64, surface y=64
fill -64 0 -64 64 63 64 stone
fill -64 64 -64 64 64 64 grass_block
fill -64 65 -64 64 319 64 air
setworldspawn 0 65 0
