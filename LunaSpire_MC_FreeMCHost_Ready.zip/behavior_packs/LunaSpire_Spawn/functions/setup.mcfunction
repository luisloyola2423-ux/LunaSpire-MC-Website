# LunaSpire MC one-time spawn/town preparation
# Creates a 129 x 129 flat grass building area centered at 0,0.
fill -64 0 -64 64 63 64 stone
fill -64 64 -64 64 64 64 grass_block
fill -64 65 -64 64 319 64 air
setworldspawn 0 65 0
scoreboard objectives add lunaSpire dummy
scoreboard players set LunaSpireSetup lunaSpire 1
