# Run the spawn setup only once.
execute unless score LunaSpireSetup lunaSpire matches 1 run function setup
