LUNASPIRE MC — FREEMCHOST-READY BEDROCK STARTER

SERVER SETTINGS
- Name: LunaSpire MC
- Survival
- Normal difficulty
- PvP enabled
- Maximum players: 200
- Public server (allow-list disabled)
- Bedrock port: 19132

SPAWN AREA
The included behavior pack creates a 129 x 129 flat grass building area centered on world spawn. The area is cleared above the grass pad so you can build a town. Natural terrain remains outside the pad when the surrounding chunks generate.

IMPORTANT FREE MCHOST SETUP
1. Create/start a Bedrock server once so FreeMCHost creates its normal folders.
2. Stop the server.
3. Extract this ZIP into the server root, replacing server.properties if prompted. Do NOT delete any existing vanilla folders/files created by the host.
4. Make sure behavior_packs/LunaSpire_Spawn/manifest.json exists directly inside that folder.
5. The pack must be enabled for the active world. If your panel provides a world/add-on manager, enable LunaSpire_Spawn. If not, use the server console after the world is created to run the pack's setup function according to the host's Bedrock add-on controls.
6. Start the server and check the console for pack-loading messages.

ONE-TIME SETUP SAFETY
The tick function runs setup only once using a scoreboard flag. It will not repeatedly clear the town area after players build there.

BACKUP
After the world is created and the spawn is correct, make a backup before inviting players.
